# -*- encoding=utf8 -*-
__author__ = "Chalet"

from airtest.core.api import *

auto_setup(__file__)  # -*- encoding=utf8 -*-
__author__ = "Chalet"

from airtest.core.api import *
from airtest.core.android.android import Android
from airtest.core.android.adb import ADB
from poco.drivers.android.uiautomation import AndroidUiautomationPoco
from poco.exceptions import PocoNoSuchNodeException
import threading
from airtest.core.error import *
import urllib
import os
import datetime
import sys
import logging

flag = True

path = os.path.abspath('.')



# 检测USB安装确认弹窗
class usb_install_thread(threading.Thread):  # 安装确认
    def __init__(self):
        threading.Thread.__init__(self)

    def run(self):  # 把要执行的代码写到run函数里面 线程在创建后会直接运行run函数
        usb_install()


def usb_install():
    while True:
        if not flag:
            break
        try:
            if poco(text='继续安装').exists():
                poco(text='继续安装').click()
        except:
            pass
        try:
            if poco(text='继续安装').exists():
                sleep(1.0)
                poco(text='继续安装').click()
        except:
            pass
        try:
            if poco(text='允许').exists():
                poco(text='允许').click()
        except:
            pass
        try:
            if poco(text='允许').exists():
                poco(text='允许').click()
        except:
            pass
        try:
            if poco(text='确认').exists():
                poco(text='确认').click()
        except:
            pass


class permission_deal_thread(threading.Thread):  # 处理权限
    def __init__(self):
        threading.Thread.__init__(self)

    def run(self):  # 把要执行的代码写到run函数里面 线程在创建后会直接运行run函数
        permission_deal()


def permission_deal():
    while True:
        if flag == False:
            break;
        try:
            if poco(text='允许').exists():
                poco(text='允许').click()
            if poco(text='始终允许').exists():
                poco(text='始终允许').click()
            if poco("miui:id/up").exists():
                poco("miui:id/up").click()
            if poco("向上导航").exists():
                poco("向上导航").click()
            if poco("com.android.settings:id/mz_toolbar_nav_button").exists():  # 魅族20180104-19兼容
                poco("com.android.settings:id/mz_toolbar_nav_button").click()
            if poco(text='知道了').exists():
                poco(text='知道了').click()
        except:
            pass


android = Android(serialno=None, host=None, cap_method='MINICAP_STREAM', touch_method='MINITOUCH',
                  ime_method='YOSEMITEIME', ori_method='MINICAPORI')
poco = AndroidUiautomationPoco(use_airtest_input=True, screenshot_each_action=False)

# 开启线程处理权限弹窗
thread2 = permission_deal_thread()
thread2.start()


try:
    start_app("com.corp21cn.mail189")
    poco(text='添加账号').wait_for_appearance()
    poco(text='添加账号').click()
    poco("com.corp21cn.mail189:id/mail_set_select").child("android.widget.LinearLayout")[0].click()
    touch(Template(r"tpl1535438549016.png", record_pos=(0.199, 0.626), resolution=(1440, 2560)))
    try:
        touch(Template(r"tpl1535506987254.png", record_pos=(-0.41, -0.266), resolution=(1440, 2560)))
    except:
        poco.click([0.089, 0.35])
    poco("j-username-box").child("j-userName").click()
    text("17748482592")
    try:
        poco("j-password").click()
    except:
        poco.click([0.5, 0.26484375])
    text('15983760537chao.')
    poco(text='登录').click()
    sleep(3)
    flag = False
    dev = device()
    dev.shell("monkey -p com.corp21cn.mail189 --throttle 600 -v 300")
    stop_app("com.corp21cn.mail189")
    
    sys.exit(0)
except PocoNoSuchNodeException as e:
    logging.exception(e)
    sys.exit(1)

